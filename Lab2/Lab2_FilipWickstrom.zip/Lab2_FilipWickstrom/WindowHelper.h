#pragma once
#include <Windows.h>
#include <iostream>

bool SetupWindow(HINSTANCE instance, UINT width, UINT height, int nCmdShow, HWND& window);